use master
go

CREATE DATABASE AutoDiller
ON PRIMARY
(
Name = AutoDiller_dat,
FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\autodiller_dat.mdf',
SIZE = 10,
MAXSIZE = 50,
FILEGROWTH = 5
)
LOG ON
(
Name = AutoDiller_log,
FILENAME = 'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\autodiller_log.ldf',
SIZE = 5,
MAXSIZE = 25,
FILEGROWTH = 1
)

use AutoDiller
go
--unique
--�������
--���������
--��������
--������������
--�����������
--�������������

CREATE TABLE Users
(
	Id int identity(1,1) primary key not null,
	Username varchar(20) unique not null,
	Passkey varchar(20) not null,
	Contact int not null,
	UserRole int null,
	Photo int null,
)
go

ALTER TABLE Users
ADD CONSTRAINT CheckUsername CHECK (Username LIKE ('___%'))
ALTER TABLE Users
ADD	CONSTRAINT CheckPasskey CHECK (Passkey LIKE ('%[A-Z]%[a-z]%[0-9]%'))

CREATE TABLE Roles
(
	Id int identity(1,1) primary key not null,
	UserRole varchar(20) unique not null
)
go

CREATE TABLE Contacts
(
	Id int identity(1,1) primary key not null,
	Secondname varchar(20) not null,
	Firstname varchar(20) not null,
	Thirdname varchar(20) null,
	Phone char(12) null,
	NumberPassport int not null,
	SerialPassport int not null
)
go

ALTER TABLE Contacts
ADD CONSTRAINT CheckSecondname CHECK (Secondname LIKE ('[�-�]%'))
ALTER TABLE Contacts
ADD CONSTRAINT CheckFirstname CHECK (Firstname LIKE ('[�-�]%'))
ALTER TABLE Contacts
ADD CONSTRAINT CheckThirdname CHECK (Thirdname LIKE ('[�-�]%'))
ALTER TABLE Contacts
ADD CONSTRAINT CheckPhone CHECK (Firstname LIKE ('%[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'))
--�������

CREATE TABLE Sales
(
	Id int identity(1,1) primary key not null,
	Manager int null,
	Customer int null,
	Purchase bit default 0 not null,
	Car int not null,
	FullPrice float null
)
go

ALTER TABLE Sales
ADD CONSTRAINT CheckFullPrice CHECK (FullPrice > 0)

CREATE TABLE InfoCars
(
	Id int identity(1,1) primary key not null,
	Mileage float not null,
	Gear int not null,
	GearBox bit not null,
	BodyType int not null,
	Tank float not null,
	Photo int null,
	Place varchar(80) null
)

ALTER TABLE InfoCars
ADD CONSTRAINT CheckMileage CHECK (Mileage >= 0)
ALTER TABLE InfoCars
ADD CONSTRAINT CheckTank CHECK (Tank > 0)
--�����

CREATE TABLE SearchCars
(
	Id int identity(1,1) primary key not null,
	VIN varchar(17) unique not null,
	Mark int not null,
	Model varchar(40) not null,
	Country int not null,
	YearBorn int null
)
go

ALTER TABLE SearchCars
ADD CONSTRAINT CheckVIN CHECK (VIN LIKE ('___________[0-9][0-9][0-9][0-9][0-9][0-9]'))
ALTER TABLE SearchCars
ADD CONSTRAINT CheckYearBorn CHECK (YearBorn LIKE ('[1,2][0-9][0-9][0-9]'))

CREATE TABLE PriceCars
(
	Id int identity(1,1) primary key not null,
	Price float not null,
	TechnicalType varchar(200) null
)

ALTER TABLE PriceCars
ADD CONSTRAINT CheckPrice CHECK (Price > 0)





CREATE TABLE Mark
(
	Id int identity(1,1) primary key not null,
	Mark varchar(30) unique not null
)

CREATE TABLE Country
(
	Id int identity(1,1) primary key not null,
	Country varchar(20) unique not null
)


CREATE TABLE Gear
(
	Id int identity(1,1) primary key not null,
	Gear varchar(20) unique not null
)

CREATE TABLE BodyType
(
	Id int identity(1,1) primary key not null,
	BodyType varchar(20) unique not null
)

CREATE TABLE Gallery
(
	Id int identity(1,1) primary key not null,
	Photo image null
)
go

exec sp_addumpdevice 'disk','dbAuto' ,'E:\AutoDiller\AutoDiller.bak'
Backup database AutoDiller
To dbAuto

Insert into Roles(UserRole)
Values('Expert')
Insert into Roles(UserRole)
Values('Manager')
Insert into Roles(UserRole)
Values('Director')
Insert into Roles(UserRole)
Values('Sysadmin')

Insert into Gear(Gear)
Values('��������')
Insert into Gear(Gear)
Values('������')
Insert into Gear(Gear)
Values('������')

Insert into BodyType(BodyType)
Values('������� 5 ��.')
Insert into BodyType(BodyType)
Values('������� 3 ��.')
Insert into BodyType(BodyType)
Values('�������� �����')
Insert into BodyType(BodyType)
Values('����')
Insert into BodyType(BodyType)
Values('����')
Insert into BodyType(BodyType)
Values('�����')
Insert into BodyType(BodyType)
Values('�������')
Insert into BodyType(BodyType)
Values('���������')
Insert into BodyType(BodyType)
Values('�����')
Insert into BodyType(BodyType)
Values('�������')

Insert Into Country(Country)
Values('����� �����')

Insert into Mark(Mark)
Values('KIA')

Insert into Gallery(Photo)
SELECT BulkColumn FROM OpenRowSet
(Bulk N'E:\AutoDiller\KiaRioXIV.jpg',
SINGLE_BLOB) AS KiaRioXIV

Insert into Gallery(Photo)
SELECT BulkColumn FROM OpenRowSet
(Bulk N'E:\AutoDiller\EvdokimMark.jpg',
SINGLE_BLOB) AS EvdokimMark

Insert into SearchCars(VIN, Mark, Model, Country, YearBorn)
Values('Z94FY41FTMK825166', 1, 'Rio X IV WHITE', 1, 2020)

Insert into InfoCars(Mileage, Gear, GearBox, BodyType, Tank, Photo, Place)
Values(0, 1, 1, 1, 1.6, 1, '� �������')

Insert into PriceCars(Price, TechnicalType)
VALUES (1500000, '��� ���������� ��������������. ���������� � ������ �������')

Insert into Contacts (Secondname, Firstname, Thirdname, Phone, NumberPassport, SerialPassport)
Values('���������', '����', '���������', '+77682579979', 747796, 4595)

Insert into Contacts (Secondname, Firstname, Thirdname, Phone, NumberPassport, SerialPassport)
Values('��������', '������', '�����������', '+79332987931', 456263, 4970)

Insert into Users(Username, Passkey, Contact, UserRole, Photo)
VALUES('EvdokimMA', 'MCsV2Q', 1, 2, 2)

Insert into Sales(Manager, Customer, Purchase, Car, FullPrice)
VALUES (1, 2, 1, 1, 1700000)

SELECT * FROM SearchCars
SELECT * FROM BodyType
SELECT * FROM SearchCars
Select * from Gallery
SELECT * FROM InfoCars
SELECT * FROM Contacts
SELECT * FROM Sales


RESTORE DATABASE AutoDiller FROM DISK = 'E:\AutoDiller\AutoDiller.bak'

use AutoDiller