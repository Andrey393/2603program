﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using Excel = Microsoft.Office.Interop.Excel;

namespace Mnogookno.Окны
{
    public partial class Oformit_zakaz : Form
    {
        List<Pizza> pizzas;
        public double balansZakaz;
        public double balansOrdered;
        public Oformit_zakaz()
        {
            InitializeComponent();
        }

        public Oformit_zakaz(List<Pizza> pizzas)
        {
            InitializeComponent();
            this.pizzas = pizzas;
            
        }

        private void Pay_but_Click(object sender, EventArgs e)
        {
            if (CardRB.Checked)
            {
                balansZakaz += balansOrdered * 0.1;
                MessageBox.Show($"Сумма кэшбека составит {balansOrdered * 0.1}р." +
                    $"\nНа вашей карте: {balansZakaz}р.");
            }

                
            MakeOrder makeOrder = new MakeOrder();
            MainMenuPizza mainMenuPizza = new MainMenuPizza();
            makeOrder.balansOrdered = 0;
            makeOrder.pizzas = new List<Pizza>();
            mainMenuPizza.balans = balansZakaz;
            pizzas.Clear();
            MessageBox.Show($"Вы оплатили сумму заказа на {balansOrdered}р." +
                $"\nБаланс: {balansZakaz}р.");
            CreateCheck();
            CreateWordCheck();
            GC.Collect();
            this.Close();
        }

        void CreateWordCheck()
        {
            ClassWord.wordApp = new Word.Application();
            ClassWord.wordDoc = ClassWord.wordApp.Documents.Add();
            ClassWord.wordDoc.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait;
            ClassWord.wordDoc.Content.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
            ClassWord.ParagraphCreate(1);
            ClassWord.wordShape = ClassWord.wordDoc.InlineShapes.AddPicture(Application.StartupPath + @"/images/кот.jpg",
                Type.Missing, Type.Missing, ClassWord.wordRange);
            ClassWord.wordShape.Width = 100;
            ClassWord.wordShape.Height = 100;
            ClassWord.WordWrite("Адрес: г. Санкт-Петербург,\nзагребский б-р, 24", "Left");
            ClassWord.wordRange.Font.Italic = 1;
            ClassWord.wordRange.Font.Size = 9;
            ClassWord.ParagraphCreate(2);
            
            ClassWord.WordWrite($"Дата заказа: {DateTime.Now.ToLongDateString()} Время заказа: {DateTime.Now.ToLongTimeString()}", "Center");
            ClassWord.wordRange.Font.ColorIndex = Word.WdColorIndex.wdGray50;
            ClassWord.wordRange.Font.Bold = 1;
            ClassWord.wordRange.Font.Size = 14;

            ClassWord.ParagraphCreate(2);
            ClassWord.CreateTable(ZakazTable.RowCount + 1, ZakazTable.ColumnCount);

            for (int i = 1; i <= 6; i++)
            {
                ClassWord.tablRange = ClassWord.wordTable.Cell(1, i).Range;
                ClassWord.tablRange.Text = ZakazTable.Columns[i - 1].HeaderText;
                ClassWord.wordTable.Cell(1, i).Shading.BackgroundPatternColorIndex = Word.WdColorIndex.wdBrightGreen;
                ClassWord.tablRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            }

            for (int i = 0; i < ZakazTable.RowCount; i++)
            {
                for (int j = 0; j < ZakazTable.ColumnCount; j++)
                {
                    ClassWord.tablRange = ClassWord.wordTable.Cell(i + 2, j + 1).Range;
                    ClassWord.tablRange.Text = ZakazTable[j, i].Value.ToString();
                    ClassWord.tablRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
                }
            }

            ClassWord.ParagraphCreate(1);
            if (NalichRB.Checked)
                ClassWord.WordWrite($"Кол-во позиций: {ZakazTable.Rows.Count} Оплата наличными. Чек на сумму {ConvertRub(balansOrdered)}", "Left");
            else
                ClassWord.WordWrite($"Кол-во позиций: {ZakazTable.Rows.Count} Оплата картой. Чек на сумму {ConvertRub(balansOrdered)}", "Left");
            ClassWord.wordRange.Font.Italic = 1;
            ClassWord.ParagraphCreate(3);
            ClassWord.wordShape = ClassWord.wordDoc.InlineShapes.AddPicture(Application.StartupPath + @"/images/pech.png",
                Type.Missing, Type.Missing, ClassWord.wordRange);
            ClassWord.wordShape.Width = 150;
            ClassWord.wordShape.Height = 200;

            ClassWord.wordShape = ClassWord.wordDoc.InlineShapes.AddPicture(Application.StartupPath + @"/images/podp.png",
                Type.Missing, Type.Missing, ClassWord.wordRange);
            ClassWord.wordShape.Width = 70;
            ClassWord.wordShape.Height = 70;


            string pathBook = Application.StartupPath + @"\" + DateTime.Now.ToShortDateString().Replace('.', '_') + "_" + DateTime.Now.ToLongTimeString().Replace(':', '_') + ".docx";
            ClassWord.wordDoc.SaveAs2(pathBook, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Word.WdSaveFormat.wdFormatDocument, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            pathBook = Application.StartupPath + @"\" + DateTime.Now.ToShortDateString().Replace('.', '_') + "_" + DateTime.Now.ToLongTimeString().Replace(':', '_') + ".pdf";

            ClassWord.wordDoc.ExportAsFixedFormat(pathBook, Word.WdExportFormat.wdExportFormatPDF);
            ClassWord.wordDoc.Close(true, null, null);
            ClassWord.wordApp.Quit();
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(ClassExcel.excelApp);
        }

        void CreateCheck()
        {
            Excel.Application excelCheck = new Excel.Application();
            excelCheck.SheetsInNewWorkbook = 1;
            Excel.Workbook excelCheckBook = excelCheck.Workbooks.Add(Type.Missing);
            excelCheck.DisplayAlerts = false;
            Excel.Worksheet excelCheckSheet = excelCheck.Worksheets[1];
            excelCheckSheet.Name = "Чек";
            Excel.Range excelCheckCells;
            excelCheckCells = (Excel.Range)excelCheckSheet.Cells[1][1];
            excelCheckCells.Value2 = $"Дата заказа: {DateTime.Now.ToLongDateString()} Время заказа: {DateTime.Now.ToLongTimeString()}";

            for (int i = 1; i <= 6; i++)
            {
                excelCheckCells = (Excel.Range)excelCheckSheet.Cells[i][2];
                excelCheckCells.Value2 = ZakazTable.Columns[i - 1].HeaderText;
                excelCheckCells.Interior.ColorIndex = 34;
                excelCheckCells.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            }

            for (int i = 0; i < ZakazTable.RowCount; i++)
            {
                for (int j = 0; j < ZakazTable.ColumnCount;j++)
                {
                    excelCheckCells = (Excel.Range)excelCheckSheet.Cells[i + 3, j + 1];
                    excelCheckCells.Value2 = ZakazTable[j, i].Value;
                }
            }

            excelCheckCells = (Excel.Range)excelCheckCells.Cells[4, -4];

            if (NalichRB.Checked)
                excelCheckCells.Value2 = $"Кол-во позиций: {ZakazTable.Rows.Count} Оплата наличными. Чек на сумму {ConvertRub(balansOrdered)}";
            else
                excelCheckCells.Value2 = $"Кол-во позиций: {ZakazTable.Rows.Count} Оплата картой. Чек на сумму {ConvertRub(balansOrdered)}";

            excelCheckCells.Font.Italic = true;
            excelCheckSheet.Shapes.AddPicture(Application.StartupPath + @"/images/кот.jpg", Microsoft.Office.Core.MsoTriState.msoFalse, Microsoft.Office.Core.MsoTriState.msoCTrue, 500, 0, 100, 100);
            excelCheckCells = (Excel.Range)excelCheckCells.Cells[3, 10];
            excelCheckCells.Value2 = "Адрес: г. Санкт-Петербург, загребский б-р, 24";
            excelCheckSheet.Columns[2].ColumnWidth = 30;
            excelCheckSheet.Columns[3].ColumnWidth = 30;
            excelCheckCells = (Excel.Range)excelCheckSheet.get_Range("A1", "C1");
            excelCheckCells.Merge(Type.Missing);
            excelCheckCells.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            excelCheckCells.Borders.ColorIndex = 2;
            excelCheckCells.Font.Color = Color.DarkGray;

            excelCheckBook.Saved = true;
            string pathBook = Application.StartupPath + @"\" + DateTime.Now.ToShortDateString().Replace('.', '_') + "_" + DateTime.Now.ToLongTimeString().Replace(':', '_') + ".xlsx";
            excelCheckBook.SaveAs(pathBook, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            excelCheckBook.Close(true, null, null);
            excelCheck.Quit();
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(excelCheck);


        }

        private void Oformit_zakaz_Load(object sender, EventArgs e)
        {
            if (pizzas == null)
            {
                MessageBox.Show("Выберите товар");
                return;
            }
            MakeOrder mo = this.Owner as MakeOrder;
            balansOrdered = mo.balansOrdered;
            ZakazTable.Rows.Clear();
            ZakazTable.RowCount = pizzas.Count;
            
          
        
            for (int i = 0; i < pizzas.Count; i++)
            {
                ZakazTable.Rows[i].Cells[0].Value = i + 1;
                ZakazTable.Rows[i].Cells[1].Value = pizzas[i].category;
                ZakazTable.Rows[i].Cells[2].Value = pizzas[i].name;
                ZakazTable.Rows[i].Cells[3].Value = pizzas[i].price;
                ZakazTable.Rows[i].Cells[4].Value = pizzas[i].count;
                ZakazTable.Rows[i].Cells[5].Value = pizzas[i].price * pizzas[i].count;
            }
            StoimLabel.Text = $"Сумма на Ваш заказ: {balansOrdered}";
        }

        string ConvertRub(double rub)
        {
            string rubley = rub.ToString();
            int rubint = (int)rub;
            rubint = rubint % 10;
            if (rubint == 1)
                rubley += " рубль";
            if (rubint > 1 && rubint < 5)
                rubley += " рубля";
            if (rubint == 0 || rubint >= 5)
                rubley += " рублей";
            return rubley;
        }

        private void Vernutsa_but_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
