﻿using Mnogookno.Окны;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mnogookno
{
    public partial class ModMenu : Form
    {
        public List<Pizza> menusModMenu;
        public List<int> orderedModMenu;
        public bool alarm = false;

        public ModMenu()
        {
            InitializeComponent();
        }


        private void CostPizza_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;

            if (!Char.IsDigit(number) && !Char.IsControl(number) && number != ',')
            {
                e.Handled = true;
            }
        }

        private void ExitButMod_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            string category = cbCategory.SelectedItem.ToString();
            cbName.Items.Clear();
            for (int i = 2; i <= ClassExcel.GetCellsRow(ClassExcel.GetLastCells(category)); i++)
            {
                if (ClassExcel.CheckNullCell(category, i, 1, 5))
                {
                    cbName.Items.Add(ClassExcel.GetCellsString(category, i, 1));
                }

            }
            cbName.SelectedIndex = 0;
        }

        private void cbName_SelectedIndexChanged(object sender, EventArgs e)
        {
            string category = cbCategory.SelectedItem.ToString();
            string itemFood = cbName.SelectedItem.ToString();
            for (int i = 2; i <= ClassExcel.GetCellsRow(ClassExcel.GetLastCells(category)); i++)
            {
                if (ClassExcel.CheckNullCell(category, i, 1, 5) && ClassExcel.GetCellsString(category, i, 1) == itemFood)
                {
                    tbNameFood.Text = ClassExcel.GetCellsString(category, i, 1);
                    tbCostFood.Text = ClassExcel.GetCellsDouble(category, i, 2).ToString();
                    tbKkalFood.Text = ClassExcel.GetCellsDouble(category, i, 3).ToString();
                    tbWeightFood.Text = ClassExcel.GetCellsDouble(category, i, 4).ToString();
                    tbDeskFood.Text = ClassExcel.GetCellsString(category, i, 5);
                }

            }
            
        }

        private void btFoodChange_Click(object sender, EventArgs e)
        {
            string category = cbCategory.SelectedItem.ToString();
            string itemFood = cbName.SelectedItem.ToString();
            for (int i = 2; i <= ClassExcel.GetCellsRow(ClassExcel.GetLastCells(category)); i++)
            {
                if (ClassExcel.CheckNullCell(category, i, 1, 5) && ClassExcel.GetCellsString(category, i, 1) == itemFood)
                {
                    ClassExcel.excelCells.Cells[i,1] = tbNameFood.Text;
                    ClassExcel.excelCells.Cells[i, 2] = tbCostFood.Text;
                    ClassExcel.excelCells.Cells[i, 3] = tbKkalFood.Text;
                    ClassExcel.excelCells.Cells[i, 4] = tbWeightFood.Text;
                    ClassExcel.excelCells.Cells[i, 5] = tbDeskFood.Text;
                }

            }
            ClassExcel.excelBook.Saved = true;
        }
    }
}
