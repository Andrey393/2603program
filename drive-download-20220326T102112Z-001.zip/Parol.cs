﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mnogookno.Окны
{
    public partial class Parol : Form
    {
        public Parol()
        {
            InitializeComponent();
        }
        
        private void Parol_button_Click(object sender, EventArgs e)
        {
            if (Parol_texbox.Text == "and")
            {
                ModMenu modMenu = new ModMenu();
                if (ClassExcel.excelBook.Sheets[1].Name == "Каталог")
                {
                    modMenu.cbCategory.Items.Clear();
                    modMenu.cbName.Items.Clear();
                    for (int i = 1; i <= ClassExcel.GetCellsRow(ClassExcel.GetLastCells("Каталог")); i++)
                    {
                        ClassExcel.GetCells("Каталог", i, 1);
                        if (ClassExcel.excelCells != null && ClassExcel.excelCells.Value2 == ClassExcel.excelBook.Sheets[i + 1].Name)
                        {
                            modMenu.cbCategory.Items.Add(ClassExcel.excelCells.Value2);
                        }
                    }
                }
                this.Hide();
                modMenu.ShowDialog(); 
                this.Close();
            }
            else
            {
                MessageBox.Show("Неправильный пароль");
            }
        }

        private void ExitCheckButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
