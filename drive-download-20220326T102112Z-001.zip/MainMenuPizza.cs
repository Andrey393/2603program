﻿using Mnogookno.Окны;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;
using System.Diagnostics;

namespace Mnogookno
{

    public partial class MainMenuPizza : Form
    {
        public double balans = -1;
        public List<Pizza> pizzas;
        public double balansOrdered;

        public MainMenuPizza()
        {
            InitializeComponent();
        }
        
         void MenuButtons(object sender, EventArgs e)
         {
            Button but=(Button)sender;
            switch (but.Tag)
            {
                case "Zakaz":
                    MakeOrder makeOrder = new MakeOrder();
                    makeOrder.balansMakeOrder = balans;
                    makeOrder.balansOrdered = this.balansOrdered;
                    makeOrder.pizzas = this.pizzas;
                    if (ClassExcel.excelBook.Sheets[1].Name == "Каталог")
                    {
                        makeOrder.MenuList.Items.Clear();
                        for (int i = 1; i <= ClassExcel.GetCellsRow(ClassExcel.GetLastCells("Каталог")); i++)
                        {
                            ClassExcel.GetCells("Каталог", i, 1);
                            if (ClassExcel.excelCells != null && ClassExcel.excelCells.Value2 == ClassExcel.excelBook.Sheets[i+1].Name)
                            {
                                makeOrder.MenuList.Items.Add(ClassExcel.excelCells.Value2);
                            }
                        }
                        makeOrder.OrderedList.Items.Clear();
                        if (!(pizzas is null))
                        {
                            foreach(Pizza pizza in pizzas)
                                makeOrder.OrderedList.Items.Add(pizza + ": " + pizza.count);
                        }
                    }

                    this.Hide();
                    makeOrder.ShowDialog();
                    balans = makeOrder.balansMakeOrder;
                    balansOrdered = makeOrder.balansOrdered;
                    pizzas = makeOrder.pizzas;
                    this.Show();
                    break;

                case "Modering":
                    if (pizzas is null || pizzas.Count == 0)
                    {
                        Parol parol = new Parol();
                        this.Hide();
                        parol.ShowDialog();
                        this.Show();
                    }
                    else
                    {
                        MessageBox.Show("Оплатите или удалите заказ перед управлением меню");
                    }
                    
                    break;
                case "PriceList":
                    if (ClassExcel.excelApp.Visible)
                    {
                        List_button.Text = "Прайc-лист";
                        ClassExcel.excelApp.Visible = false;                     
                    }
                    else
                    {
                        ClassExcel.excelApp.Visible = true;
                        List_button.Text = "Закрыть Excel";
                    }
                        
                    break;
                case "Exit": this.Close();break;
            }
         }

        private void MainMenuPizza_Load(object sender, EventArgs e)
        {
            
            if (balans == -1)
            {
                MakeOrder makeOrder = new MakeOrder();
                makeOrder.BalanceChart.Visible = false;
                ClassExcel.excelApp = new Excel.Application();
                ClassExcel.excelApp.Visible = false;
                ClassExcel.excelBook = ClassExcel.excelApp.Workbooks.Open(Application.StartupPath + @"\pricelist.xlsx");
                Random random = new Random();
                balans = random.Next(2000, 6000);
                
            }
        }

        private void MainMenuPizza_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                ClassExcel.excelApp.Quit();
            }
            catch
            {
                ProcessStartInfo psi = new ProcessStartInfo("cmd", @"/c taskkill /f /im EXCEL.EXE");
                Process.Start(psi);
                psi = new ProcessStartInfo("cmd", @"/c taskkill /f /im WINWORD.EXE");
                Process.Start(psi);
                Application.Exit();
            }
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(ClassExcel.excelApp);
            GC.Collect();
        }
    }
}
